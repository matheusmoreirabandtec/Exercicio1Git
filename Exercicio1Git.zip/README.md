# Exercicio1Git
Primeiro exercicio de Git
